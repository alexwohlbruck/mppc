module.exports = async sendResponse => {
    return 'Invalid action'
};