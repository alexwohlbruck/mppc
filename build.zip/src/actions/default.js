module.exports = async request => {
    return {
    	message: 'Invalid action',
    	requestData: request
    }
}