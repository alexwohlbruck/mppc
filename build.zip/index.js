const entry = require('./build');

exports.handler = entry;